import React from "react";

export default function page() {
  return <div>ABCD GAME</div>;
}
