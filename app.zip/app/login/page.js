import React from "react";

export default function page() {
  return <div>Login Page</div>;
}
